# CHANGELOG

## 1.0.0 - Initial release
- Initial implementation of DeadBody Investigator for Qbox
- Features: investigation UI, critical area highlight, cause & estimated TOD, XP/payout, SQL persistence, target provider support, server events/exports, tests and examples.
